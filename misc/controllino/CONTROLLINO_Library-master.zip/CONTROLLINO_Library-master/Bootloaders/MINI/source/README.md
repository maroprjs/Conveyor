Here you can find the only file that we have modified in the original Arduino bootloader. The only change is that there is disabled the LED blinking.

The original Arduino UNO bootloader is part of the Arduino installation:

c:\Program Files (x86)\Arduino\hardware\arduino\avr\bootloaders\optiboot\

Then you only need the avr-gcc toolchain to do your own modifications of the bootloader.
